package derspackage;

import java.util.Random;

public class DersClass {
	public static void main(String[] args) {
		
		Random random = new Random();
		String HKChars[] = {"Grimm","HollowKnight","Radiance","TheKnight","Hornet","BrokenVessel"};
		int r = random.nextInt(HKChars.length);
		System.out.println("You are : " +  HKChars[r]);
		switch(r) {
		case 0 : System.out.println("Grimm is the master of the Grimm Troupe, a mysterious travelling circus."
				+ " In truth, Grimm and his Troupe travel from the Nightmare Realm to\nwherever the Nightmare"
				+ " Lantern has been lit by acolytes. They gather Nightmare Flames from ruined lands to fuel"
				+ " the sinister being enslaving the Troupe,\nthe Nightmare's Heart.");
		System.out.println("TIER : 4");
		break;
		case 1 : System.out.println("The Hollow Knight is the Vessel chosen by the Pale King to seal away"
				+ " the Radiance and save Hallownest from the Infection. Like their siblings, they are the\n"
				+ "child of the King and Queen of Hallownest, birthed in the Abyss to be infused with the"
				+ " power of the Void. As such, they are genderless.");
		System.out.println("TIER : 4");
		break;
		case 2 : System.out.println("The Radiance is a Higher Being of light similar to Essence, and as such,"
				+ " opposed to the Void, her ancient enemy. The Moth Tribe is born from\nher light and in return"
				+ " revered her.");
		System.out.println("TIER : 5");
		break;
		case 3 : System.out.println("The Knight is a discarded Vessel. They are the child of the Pale King"
				+ " and the White Lady, born in the Abyss with Void inside their shell.\nHornet is the"
				+ " Knight's sister through their shared father. Like the rest of their Vessel siblings,"
				+ " the Knight is genderless.");
		System.out.println("TIER : 6");
		break;
		case 4 : System.out.println("Hornet is the daughter of the Pale King and Herrah the Beast, the queen"
				+ " of Deepnest. Her birth was the result of a bargain for her mother to become\na Dreamer,"
				+ " and as such, she spent only a short time with Herrah. Her shared father with the Knight"
				+ " and the rest of the Vessels makes them siblings.");
		System.out.println("TIER : 3");
		break;
		case 5 : System.out.println("Broken Vessel is found in a room of the Ancient Basin that is"
				+ " overgrown with Infection bulbs. The Infection reanimates the husk and causes it"
				+ " to attack\nthe Knight. Like other Vessels, it has no voice, but the Infection within"
				+ " screams like the Radiance.");
		System.out.println("TIER : 3");
		break;
		}
	}
}